#pragma once
class BoxCube
{
public:
	BoxCube();
	~BoxCube();
	void Render();
	void Update();
	void Debug();
	
private:
	Transform* mainBody;
	vector<Quad*> parts;
};

