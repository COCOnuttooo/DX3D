#include "Framework.h"
#include "BoxCube.h"
BoxCube::BoxCube()
{
	mainBody = new Transform;
	for (int i = 0; i < 6; i++)
	{
		parts.push_back(new Quad);
		parts[i]->SetParent(mainBody);
		parts[i]->GetMaterial()->SetDiffuseMap(L"Landscape/Box.png");
		if (i < 4)
		{
			parts[i]->rotation.x = XM_PIDIV2 * i;
			
		}
		else if (i == 4)
		{
			parts[i]->rotation.y = XM_PIDIV2;
		}
		else if (i == 5)
		{
			parts[i]->rotation.y = -XM_PIDIV2;
		}
		
	}
	parts[0]->translation.z = -0.5;
	parts[1]->translation.y = 0.5;
	parts[2]->translation.z = 0.5;
	parts[3]->translation.y = -0.5;
	parts[4]->translation.x = -0.5;
	parts[5]->translation.x = 0.5;
}

BoxCube::~BoxCube()
{
}

void BoxCube::Render()
{
	for (auto& i : parts)
	{
		i->Render();
	}
}

void BoxCube::Update()
{
	mainBody->Update();
	for (auto& i : parts)
	{
		i->Update();
	}
}

void BoxCube::Debug()
{
	if (ImGui::TreeNode("BoxOption"))
{
	ImGui::Text("Pos : %d, %d, %d", (int)mainBody->translation.x, (int)mainBody->translation.y, (int)mainBody->translation.z);
	ImGui::Text("Rot : %.2f, %.2f, %.2f", mainBody->rotation.x, mainBody->rotation.y, mainBody->rotation.z);
	ImGui::SliderFloat("Rotation X", &mainBody->rotation.x, 0, 2 * XM_PI);
	ImGui::SliderFloat("Rotation Y", &mainBody->rotation.y, 0, 2 * XM_PI);
	ImGui::SliderFloat("Rotation Z", &mainBody->rotation.z, 0, 2 * XM_PI);

	ImGui::SliderFloat("Scalee X", &mainBody->scale.x, 0, 50);
	ImGui::SliderFloat("Scalee Y", &mainBody->scale.y, 0, 50);
	ImGui::SliderFloat("Scalee Z", &mainBody->scale.z, 0, 50);
	//ImGui::SliderFloat("Move Speed", &moveSpeed, 1.0f, 50.0f);
	//ImGui::SliderFloat("Rotate Speed", &rotateSpeed, 1.0f, 50.0f);
	if (ImGui::Button("Set Default"))
	{
		mainBody->scale = { 1,1,1 };
		mainBody->rotation = { 0,0,0 };
		mainBody->translation = { 0,0,0 };

	}
	ImGui::TreePop();
}
}
