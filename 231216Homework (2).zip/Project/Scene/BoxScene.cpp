#include "Framework.h"
#include "BoxScene.h"

BoxScene::BoxScene()
{
	//quad = new Quad;
	//quad->GetMaterial()->SetDiffuseMap(L"Landscape/Box.png");
	box = new BoxCube;
}

BoxScene::~BoxScene()
{
	//delete quad;
}

void BoxScene::Update()
{
	box->Update();
}

void BoxScene::PreRender()
{

}

void BoxScene::Render()
{
	box->Render();
}

void BoxScene::PostRender()
{
	box->Debug();
}
