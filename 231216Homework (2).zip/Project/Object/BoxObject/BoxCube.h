#pragma once
class BoxCube
{
public:
	BoxCube();
	~BoxCube();
	void Render();
	void Update();
	void Debug();
	void SetTexture(wstring file);
	
private:
	Transform* mainBody;
	vector<Quad*> parts;
	vector<wstring> names;
};

