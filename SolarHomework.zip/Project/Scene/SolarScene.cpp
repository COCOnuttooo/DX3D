#include "Framework.h"
#include "SolarScene.h"
SolarScene::SolarScene()
{


}

SolarScene::~SolarScene()
{
	for (auto& i : planets)
	{
		delete i;
	}
	planets.clear();
}

void SolarScene::Update()
{
	for (auto& i : planets)
	{
		i->Update();
	}
}

void SolarScene::PreRender()
{
}

void SolarScene::Render()
{
	for (auto& i : planets)
	{
		i->Render();
	}
}

void SolarScene::PostRender()
{
}

void SolarScene::CreateRandomOrbit(Planet* planet, float length)
{
	Vector3 vec;
	do
	{
		vec = Vector3(rand() % 10 - 5, rand() % 10 - 5, rand() % 10 - 5).GetNormalized();
	} while (vec.Length() == 0);
	vec.x *= length;
	vec.y *= length;
	vec.z *= length;
	if (vec.Length()==0)
	{
		return;
	}

	planet->orbitSpeed =2;
	planet->SetInitialTranslation(vec);
	int num = rand() % 3;
	switch (num)
	{
	case 0:
		planet->rotationSpeed.x = rand() % 10;
		break;
	case 1:
		planet->rotationSpeed.y = rand() % 10;

		break;
	case 2:
		planet->rotationSpeed.z = rand() % 10;

		break;

	default:
		break;
	}
}

void SolarScene::CreateOrbit(Planet* planet, float length, Vector3 orbitVec)
{
	Vector3 vec;
	do
	{
		vec = Vector3::Cross(Vector3(rand()%3-1, rand() % 3 - 1, rand() % 3 - 1),orbitVec).GetNormalized() * length;
	} while (vec.Length() == 0);
	planet->translation = vec;
	planet->orbitSpeed = 2;
	planet->SetOrbit(orbitVec);
	int num = rand() % 3;
	switch (num)
	{
	case 0:
		planet->rotationSpeed.x = rand() % 10;
		break;
	case 1:
		planet->rotationSpeed.y = rand() % 10;

		break;
	case 2:
		planet->rotationSpeed.z = rand() % 10;

		break;

	default:
		break;
	}
}

void SolarScene::Initialize()
{
	wstring names[11] = { L"sunmap", L"mercurymap", L"venusmap",L"earthmap",L"marsmap",L"jupitermap",L"saturnmap",L"uranusmap",L"neptunemap",L"plutomap",L"moonmap" };
	float volumeScale[11] = { 2,0.38, 0.95,1 ,0.53, 11, 9, 4,4, 0.18, 0.27 };
	float lengthScale[11] = { 0.39,0.72,1,1.52,5.2,9.54,19.19,30.7,39, .48 };
	float orbitSpeedScale[10] = { 0.24,0.62,1,1.88,11.86,29.46,84,164.8,248 };
	Vector3 orbitVec[10] = { Vector3(0.0006,1,0),Vector3(0.0454,0.999,0),Vector3(0.3987,0.9171,0),Vector3(0.4256,0.9049,0),Vector3(0.0546,9985,0),Vector3(0.4498,0.8931,0),Vector3(-0.1352,0.9908,0),Vector3(0.4744,0.8803,0),Vector3(-0.5377,0.8431,0) ,Vector3(0.1163,9932,0) };
	for (int i = 0; i < 11; i++)
	{
		wstring name = L"SolarSystem/" + names[i] + L".jpg";
		planets.push_back(new Planet);
		planets[i]->SetDiffuseMap(name);
		planets[i]->scale = Vector3(volumeScale[i], volumeScale[i], volumeScale[i]) ;
	}
	for (UINT i = 1; i < 10; i++)
	{
		planets[i]->SetParent(planets[0]);
		CreateOrbit(planets[i], lengthScale[i-1] * 10, orbitVec[i-1]);
		planets[i]->SetOrbitSpeedScale(orbitSpeedScale[i - 1]);
	}
	planets[10]->SetParent(planets[3]);
	CreateOrbit(planets[10], lengthScale[9] * 10, orbitVec[9]);


	XMFLOAT4X4 fWorld;

	XMStoreFloat4x4(&fWorld, planets[0]->TestGetWorld());
	Vector3 lightDir = Vector3(fWorld._41, fWorld._42, fWorld._43);

	return;
}
