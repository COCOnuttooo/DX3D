#pragma once

namespace Utility
{
	wstring GetExtension(wstring file);


}
