#pragma once
class EnemyManager
{
public:
	EnemyManager(Transform* player);
	~EnemyManager();
	void Update();
	void Render();
	void PostRender();
	void Spawn();
	vector<Groot*> GetEnemies() { return enemies; }
private:
	vector<Groot*> enemies;
	float cooltime = 0.0f;
};

