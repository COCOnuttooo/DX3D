#pragma once
class BulletManager;
class Knight : public Character
{
	enum State
	{
		IDLE, RUN, DANCING, ARM, UNARM, ATTACKIDLE, ATTACKRUNF, ATTACKRUNB, SHOOT, MOVINGSHOOT
	} curState = IDLE; 
public:
	Knight();
	~Knight();
	void Move();
	void Update();
	void SetClip(State state);
	void Render();
	void Debug();
	void Arm();
	void UnArm();
	BulletManager* GetBullets() { return bullets; }
private:
	bool isArming = false;
	Vector3 fireHolePos;
	bool isAttacking = false;
	bool isMoving = false;
	bool isAttackReady = false;
	float moveSpeed = 6.0f;
	BulletManager* bullets;
	Model* weapon;
};
