#include "Framework.h"
#include "BulletManager.h"

BulletManager::BulletManager()
{
	for (int i = 0; i < 100; i++)
	{
		bullets.push_back(new ChickBullet);
	}
}

BulletManager::~BulletManager()
{
	for (auto& bullet : bullets)
	{
		delete bullet;
	}
}

void BulletManager::Update()
{
	cooltime -= DELTA_TIME;
	if (cooltime<= 0)
	{
		cooltime = 0;
	}
	for (auto& bullet : bullets)
	{
		bullet->Update();
	}
}

void BulletManager::Render()
{
	for (auto& bullet : bullets)
	{
		bullet->Render();
	}
}

void BulletManager::Shoot(float cooltime, Vector3 originPos, Vector3 dir)
{
	if (this->cooltime > 0)
	{
		return;
	}
	for (auto& bullet : bullets)
	{
		if (bullet->GetIsActive())
			continue;
		bullet->Shoot(originPos, dir);
		break;
	}

	this->cooltime = cooltime;
}


