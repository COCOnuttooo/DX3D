#include "Framework.h"
#include "ChickBullet.h"

ChickBullet::ChickBullet()
{
	model = new Model("Chick");
	model->SetParent(this);
	this->scale *= 0.2;
}

ChickBullet::~ChickBullet()
{
	delete model;
}

void ChickBullet::Update()
{
	if (isActive)
	{
		__super::Update();
		model->Update();
		translation += dir * speed * DELTA_TIME;
		if ((originPos - translation).Length() >= 500)
		{
			isActive = false;
		}
	}
}

void ChickBullet::Render()
{
	if (isActive)
	{
		//__super::Render();
		model->Render();
	}
}

void ChickBullet::Debug()
{
	model->Debug();
}

void ChickBullet::Shoot(Vector3 origin, Vector3 dir)
{
	if (isActive)
	{
		return;
	}
	isActive = true;
	originPos = origin;
	translation = origin;
	this->dir = dir;
}
