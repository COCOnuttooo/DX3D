#include "Framework.h"
#include "Knight.h"

Knight::Knight()
	:Character("Superman2")
{
	GetModel()->ReadClip("Ninja Idle");
	GetModel()->ReadClip("Fast Run");
	GetModel()->ReadClip("Melee Attack");
	GetModel()->ReadClip("Arm");
	GetModel()->ReadClip("Unarm");
	GetModel()->ReadClip("Rifle Idle");
	GetModel()->ReadClip("Rifle Run");
	GetModel()->ReadClip("Rifle Run Back");
	GetModel()->ReadClip("Standing Shoot");
	GetModel()->ReadClip("Running Shoot");

	GetModel()->GetClip(ARM)->AddEvent(0.5f, bind(&Knight::Arm, this));
	GetModel()->GetClip(ARM)->AddEvent(0.8f, bind(&Knight::SetClip, this, ATTACKIDLE));
	GetModel()->GetClip(UNARM)->AddEvent(0.5f, bind(&Knight::UnArm, this));
	GetModel()->GetClip(UNARM)->AddEvent(0.8f, bind(&Knight::SetClip, this, IDLE));
	//GetModel()->GetClip(ATTACKRUNF)->AddEvent(0.8f, bind(&Knight::SetClip, this, ATTACKIDL));
	
	CAMERA->SetTarget(this);
	GetModel()->GetClip(DANCING)->AddEvent(0.8f, bind(&Knight::SetClip, this, IDLE));
	bullets = new BulletManager;
	weapon = new Model("WeaponChicken");
	weapon->translation = Vector3(0.0f, 0.0f, 0.25f);
	weapon->rotation = Vector3(29.0f * XM_PI / 180, 294.0f * XM_PI / 180, -7.0f * XM_PI / 180);
	weapon->AttachToBone(GetModel(), "mixamorig:Spine2");

}

Knight::~Knight()
{
	delete bullets;
	delete weapon;
}

void Knight::Move()
{
	if (KEY_PRESS('W') && !isArming)
	{

		translation += GetForwardVector() * moveSpeed * DELTA_TIME;
		if (isAttackReady)
		{
			if (isAttacking)
			{
				SetClip(MOVINGSHOOT);
			}
			else
				SetClip(ATTACKRUNF);

		}
		else
			SetClip(RUN);
		isMoving = true;

	}

	if (KEY_PRESS('S') && !isArming)
	{
		translation -= GetForwardVector() * moveSpeed * DELTA_TIME;
		if (isAttackReady)
		{
			SetClip(ATTACKRUNB);
		}
		else
			SetClip(RUN);

		isMoving = true;
	}

	if (KEY_PRESS('A'))
	{
		rotation.y -= DELTA_TIME *3;
	}

	if (KEY_PRESS('D'))
	{
		rotation.y += DELTA_TIME * 3;
	}
	if (KEY_UP('W') || KEY_UP('S'))
	{
		if (!isArming)
		{

			if (isAttackReady)
			{
				SetClip(ATTACKIDLE);
			}
			else
				SetClip(IDLE);
			isMoving = false;
		}
	}

	if (KEY_PRESS(VK_LBUTTON) && !isArming)
	{
		if (!isAttackReady)
		{

			SetClip(DANCING);
		}
		else
		{
			isAttacking = true;

			if (isMoving && curState!= ATTACKRUNB)
			{
				SetClip(MOVINGSHOOT);
				bullets->Shoot(0.5,fireHolePos, forward);
			}
			else if(!isMoving)
			{
				bullets->Shoot(0.2,fireHolePos, forward);

				SetClip(SHOOT);
			}
		}
			
	}
	if (KEY_UP(VK_LBUTTON))
	{
		if (isAttacking && !isArming)
		{
			isAttacking = false;
			SetClip(ATTACKIDLE);
		}
	}

	if (KEY_DOWN(VK_TAB)&& !isArming)
	{
		if (isAttackReady)
		{
			SetClip(UNARM);
		}
		else
			SetClip(ARM);
		isAttackReady = !isAttackReady;
		isArming = true;
	}
}

void Knight::Update()
{
	__super::Update();
	Move();
	fireHolePos = translation + up.GetNormalized() * scale.x * 0.7 + forward.GetNormalized();
	bullets->Update();
	weapon->Update();
}

void Knight::SetClip(State state)
{
	if (curState != state)	
	{
		model->PlayClip(state);

		curState = state;
	}
}

void Knight::Render()
{
	__super::Render();
	bullets->Render();
	weapon->Render();
}

void Knight::Debug()
{
	__super::Debug();
	weapon->Debug();
}

void Knight::Arm()
{
	weapon->translation = Vector3(0.1, 0.4, 0);
	weapon->rotation = Vector3(-175.0f * XM_PI / 180, 301.0f * XM_PI / 180, 18 * XM_PI/ 180);
	weapon->AttachToBone(GetModel(), "mixamorig:RightHand");
	isArming = false;
}

void Knight::UnArm()
{
	weapon->translation = Vector3(0.0f, 0.0f, 0.25f);
	weapon->rotation = Vector3(29.0f * XM_PI / 180, 294.0f * XM_PI / 180, -7.0f * XM_PI / 180);
	weapon->AttachToBone(GetModel(), "mixamorig:Spine2");
	isArming = false;
}
