#pragma once
class Groot : public Character
{
	enum State
	{
		IDLE, STARTRUN, RUN, INJUREDRUN, FHIT, BHIT, DANCE1, DANCE2, DANCE3
	} curState = IDLE;
public:
	Groot();
	~Groot();
	void Update();
	void Render();
	void PostRender();
	void SetClip(State state);
	void SetPlayer(Transform* player) { this->player = player; }
	void Spawn();
	void TurnOff() { isActive = false; }
	void CatchPlayer();
	void RunAway();
	void StartRun();
	void CollisionCheck();
	void Dead();
	void DanceToIdle();
	bool& GetIsActive() { return isActive; };

	void RandomMotion();
private:
	bool isMotion = false;
	float motionCooltime = 0.0f;
	Transform* player;
	ProgressBar* hpBar;
	bool isRunningAway = false;
	float moveSpeed = 5.0f;
	float injuredMoveSpeed = 3.0f;
	float maxHP = 50.0f;
	float curHP = 50.0f;
	bool isDead = false;
	bool isActive = false;
	float catchTime = 0.0f;
	float vanishTime = 0.0f;

};
