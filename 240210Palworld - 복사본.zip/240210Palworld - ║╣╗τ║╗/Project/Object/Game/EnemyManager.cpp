#include "Framework.h"
#include "EnemyManager.h"
EnemyManager::EnemyManager(Transform* player)
{
	for (int i = 0; i < 50; i++)
	{
		Groot* enemy = new Groot;
		enemy->SetPlayer(player);
		enemies.push_back(enemy);
		enemy->Spawn();
	}
}

EnemyManager::~EnemyManager()
{
	for (auto& enemy : enemies)
	{
		delete enemy;
	}
}

void EnemyManager::Update()
{
	cooltime -= DELTA_TIME;
	if (cooltime <=0)
	{
		cooltime = 0;
	}
	Spawn();
	for (auto& enemy : enemies)
	{
		enemy->Update();
	}
}

void EnemyManager::Render()
{
	for (auto& enemy : enemies)
	{
		enemy->Render();
	}
}

void EnemyManager::PostRender()
{
	for (auto& enemy : enemies)
	{
		enemy->PostRender();
	}
}

void EnemyManager::Spawn()
{
	if (cooltime > 0)
	{
		return;
	}
	for (auto& enemy : enemies)
	{
		if (enemy->GetIsActive())
		{
			continue;
		}
		enemy->Spawn();
		cooltime = 1.0f;
		break;
	}
}
