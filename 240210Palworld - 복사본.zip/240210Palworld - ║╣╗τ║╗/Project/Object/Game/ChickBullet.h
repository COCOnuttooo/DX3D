#pragma once
class ChickBullet : public ColliderSphere
{
public:
	ChickBullet();
	~ChickBullet();
	void Update();
	void Render();
	void Debug();
	void Shoot(Vector3 origin, Vector3 dir);
	bool& GetIsActive() { return isActive; }
private:
	Vector3 originPos;
	Vector3 dir;
	float speed = 20.0f;
	Model* model;
	bool isActive = false;
};
