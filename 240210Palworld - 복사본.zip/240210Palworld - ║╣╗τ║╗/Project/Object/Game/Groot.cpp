#include "Framework.h"
#include "Groot.h"

Groot::Groot()
	:Character("Groot")
{
	GetModel()->ReadClip("Happy Idle");
	GetModel()->ReadClip("Running");
	GetModel()->ReadClip("Look Behind Run");
	GetModel()->ReadClip("Injured Run");
	GetModel()->ReadClip("FrontHit");
	GetModel()->ReadClip("BackHit");
	GetModel()->ReadClip("Dance1");
	GetModel()->ReadClip("Dance2");
	GetModel()->ReadClip("Dance3");
	GetModel()->GetClip(DANCE1)->AddEvent(0.9f, bind(&Groot::DanceToIdle, this));
	GetModel()->GetClip(DANCE2)->AddEvent(0.9f, bind(&Groot::DanceToIdle, this));
	GetModel()->GetClip(DANCE3)->AddEvent(0.9f, bind(&Groot::DanceToIdle, this));
	
	GetModel()->GetClip(STARTRUN)->AddEvent(0.9f, bind(&Groot::StartRun, this));
	GetModel()->GetClip(FHIT)->AddEvent(0.8f, bind(&Groot::Dead, this));
	GetModel()->GetClip(BHIT)->AddEvent(0.8f, bind(&Groot::Dead, this));
	hpBar = new ProgressBar(L"UI/hp_bar.png", L"UI/hp_bar_BG.png");

	Vector3 pos = translation;
	pos.y += 2.0f;

	hpBar->translation = CAMERA->WorldToScreenPos(pos);
	hpBar->Update();
	hpBar->scale = { 70,15,1 };

}

Groot::~Groot()
{
	delete hpBar;
}

void Groot::Update()
{
	if (isActive && !isDead)
	{
		__super::Update();
		CatchPlayer();
		RunAway();
		CollisionCheck();
		RandomMotion();

		Vector3 pos = translation;
		pos.y += 3.0f;

		hpBar->translation = CAMERA->WorldToScreenPos(pos);

		hpBar->Update();
	}
	if (isDead)
	{
		Vector3 pos = translation;
		pos.y += 3.0f;

		hpBar->translation = CAMERA->WorldToScreenPos(pos);

		hpBar->Update();
		vanishTime -= DELTA_TIME;
		if (vanishTime <= 0)
		{
			isRunningAway = false;
			vanishTime = 0;
			isActive = false;
			isDead = false;
		}
	}
}

void Groot::Render()
{
	if (isActive)
	{
		__super::Render();
	}
}

void Groot::PostRender()
{
	if (isActive)
	{
		hpBar->Render();
	}
}

void Groot::SetClip(State state)
{
	if (curState != state)
	{
		model->PlayClip(state);

		curState = state;
	}
}

void Groot::Spawn()
{
	
	if (isActive)
	{
		return;
	}
	float distance = Clamp(rand() % 100, 20, 30);
	float theta = rand() % 100 / 100.0f * 2* XM_PI;
	Vector3 dir = Vector3(cos(theta), 0, sin(theta)) * distance;
	Vector3 pos = player->GetGlobalPosition() +  dir;
	pos.y = scale.y * 2;
	translation = pos;
	isActive = true;
	GetModel()->GetIsPlay() = true;
	curHP = maxHP;
	hpBar->SetValue(curHP / maxHP);

	__super::Update();
}

void Groot::CatchPlayer()
{
	if (isRunningAway)
	{
		return;
	}
	if (curState == BHIT || curState == FHIT)
	{
		return;
	}
	float distance = (player->GetGlobalPosition() - translation).Length();
	if (distance <= 10)
	{
		Vector3 dir = player->GetGlobalPosition() - translation;

		float phi = atan2f(dir.x, dir.z);
		rotation.y = phi;

		SetClip(STARTRUN);
	}

}

void Groot::RunAway()
{
	if (isRunningAway)
	{
		if (curState == RUN)
		{

			translation += forward * moveSpeed * DELTA_TIME;
		}
		else if (curState == INJUREDRUN)
		{
			translation += forward * injuredMoveSpeed * DELTA_TIME;
		}


		float distance = (player->GetGlobalPosition() - translation).Length();
		if (distance >= 40)
		{
			SetClip(IDLE);
			isRunningAway = false;
		}
	}
}

void Groot::StartRun()
{
	Vector3 dir = player->GetGlobalPosition() - translation;
	float theta = dir.x / dir.z;
	float phi = asinf(theta);
	rotation.y += XM_PI;
	translation += forward.GetNormalized() * -4;
	SetClip(RUN);
	isRunningAway = true;
	//__super::Update();
}

void Groot::CollisionCheck()
{
	Knight* character = dynamic_cast<Knight*>(player);
	for (auto& bullet : character->GetBullets()->GetBullets())
	{
		if (!bullet->GetIsActive())
		{
			continue;
		}
		if (bullet->Collision(this))
		{
			bullet->GetIsActive() = false;
			Vector3 dir = -(character->GetGlobalPosition() - translation).GetNormalized();
			curHP -= 10;
			hpBar->SetValue(curHP / maxHP);
			if (isRunningAway && curHP <= 20)
			{
				SetClip(INJUREDRUN);
			}
			if (curHP <= 0 && curState != FHIT && curState != BHIT)
			{
				curHP = 0;
				if (Vector3::Dot(dir, forward) <= 0 )
				{
					SetClip(FHIT);
				}
				else
				{
					SetClip(BHIT);
				}

			}
		}
	}
}

void Groot::Dead()
{
	isDead = true;
	vanishTime = 5;
	SetClip(IDLE);

}

void Groot::DanceToIdle()
{
	SetClip(IDLE);
	isMotion = false;
}

void Groot::RandomMotion()
{

	if (isRunningAway)
	{
		return;
	}
	int randNum = rand() % 3 + 6;
	
	if (!isMotion)
	{
		motionCooltime -= DELTA_TIME;
	}
	if (motionCooltime <= 0)
	{
		isMotion = true;
		motionCooltime = 3;
		SetClip(State(randNum));
	}
}


