#pragma once
class BulletManager
{
public:
	BulletManager();
	~BulletManager();
	void Update();
	void Render();
	void Shoot(float cooltime ,Vector3 originPos, Vector3 dir);
	vector<ChickBullet*> GetBullets() { return bullets; }
private:
	float cooltime = 0.0f;
	vector<ChickBullet*> bullets;
};
