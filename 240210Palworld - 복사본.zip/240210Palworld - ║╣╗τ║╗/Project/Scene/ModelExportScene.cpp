#include "Framework.h"
#include "ModelExportScene.h"

ModelExportScene::ModelExportScene()
{
	string name = "Groot";
	exporter = new ModelExporter(name);
	//exporter->ExportModel();	
	model = new Model(name);
	exporter->ExportAnimation("Dance1");
	exporter->ExportAnimation("Dance2");
	exporter->ExportAnimation("Dance3");
	exporter->ExportAnimation("Injured Run");
	//exporter->ExportAnimation("BackHit");
	//exporter->ExportAnimation("FrontHit");
	//model->ReadClip("Happy Idle");
}

ModelExportScene::~ModelExportScene()
{
	delete exporter;
	delete model;
}

void ModelExportScene::Update()
{
	model->Update();
}

void ModelExportScene::PreRender()
{
}

void ModelExportScene::Render()
{
	model->Render();
}

void ModelExportScene::PostRender()
{
	model->Debug();
}
