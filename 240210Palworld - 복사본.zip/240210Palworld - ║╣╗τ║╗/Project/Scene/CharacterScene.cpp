#include "Framework.h"
#include "CharacterScene.h"

CharacterScene::CharacterScene()
{
	player = new Knight;
	player->translation = Vector3(0, 2, 0);
	enemy = new EnemyManager(player);
	enemy->Spawn();
	crossHair = new Quad;
	crossHair->GetMaterial()->SetDiffuseMap(L"UI/CrossHair.png");
	crossHair->GetMaterial()->SetShader(L"01_Texture");
	crossHair->translation = { WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f, 0.0f };
	crossHair->scale = { 100,100,1 };
}

CharacterScene::~CharacterScene()
{
	delete player;
	delete enemy;
}

void CharacterScene::Update()
{
	crossHair->translation = mousePos;
	crossHair->Update();
	player->Update();
	enemy->Update();
	SetTarget();
}

void CharacterScene::PreRender()
{
	
}

void CharacterScene::Render()
{
	player->Render();
	enemy->Render();
}

void CharacterScene::PostRender()
{
	player->Debug();
	ENVIRONMENT->PostSet();

	STATE->EnableAlpha();
	STATE->DisableDepth();
	crossHair->Render();
	enemy->PostRender();
	STATE->EnableDepth();
	//enemy->Debug();
	//player->GetChick()->Debug();
}

void CharacterScene::SetTarget()
{
	Ray ray = CAMERA->ScreenPointToRay(mousePos);
	HitResult hitResult;
	for (auto& enem : enemy->GetEnemies())
	{
		if (enem->Collision(ray,&hitResult))
		{
			Vector3 dir = player->GetGlobalPosition() - enem->GetGlobalPosition();

			float phi = atan2f(dir.x, dir.z);
			if (KEY_PRESS(VK_LBUTTON))
			{

				player->rotation.y = phi + XM_PI;
			}
			return;
		}

	}
}

